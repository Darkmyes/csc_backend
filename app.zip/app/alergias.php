<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class alergias extends Model
{
    protected $fillable = [
        'nombre'
    ];
}
