<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enfermedades extends Model
{
    protected $fillable = [
        'nombre'
    ];
}
