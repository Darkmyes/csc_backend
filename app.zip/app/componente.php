<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class componente extends Model
{
    protected $fillable = [
        'nombre'
    ];
}
