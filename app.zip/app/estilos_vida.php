<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class estilos_vida extends Model
{
    protected $fillable = [
        'nombre'
    ];
}
