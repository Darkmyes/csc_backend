<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class categoria_alimento extends Model
{
    protected $fillable = [
        'nombre'
    ];
}
